document.querySelector("button").addEventListener("click", () =>{
  var result = 1;
  var input = Number(document.querySelector("input").value);
  for(let i = input; i >= 1; i--){
    result *= i
  }
  alert(result);
})
